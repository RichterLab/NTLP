
Description of running les.F (EL-ABL under the Github branch) on HPCMP-Onyx:
File differences: les.run, params.in, les.F
main changes: File locations (les.run + params.in), some hard-coded and general coding changes with respect to stationary probe implementation that takes account of increased grid number.
Additionally, implementation of an aircraft probe.

In order to run this code under the HPCMP-Onyx, you must remove all the files in the subroutine folder, put the les.F file, and compile as usual (under doing
mkdir build, cmake ../, make, etc.

The les.run and params.in are to be in their same location.

Reach me (hpark6@alumni.nd.edu) or drichte2@nd.edu for any questions regarding the development of this branch of the NTLP code.